/scratch/PI/horence/gillian/All_GLM_test

Command to call is
cd /scratch/PI/horence/gillian/MACHETE/
sh All_Samples_GLMandReports.sh <PATH_TO_NEW_OUTPUTDIR> <owners>


notes
1. path does NOT  have to already exist - is created by script
2. path must end in "/"
3. owners or horence are both possible and optional